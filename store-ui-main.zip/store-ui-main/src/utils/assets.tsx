let data = {
    'categories': [
        {
            'name': 'Top Offers',
            'image': '../assets/images/categories/offers.webp',
        },
        {
            'name': 'Electronics',
            'image': '../assets/images/categories/electronics.webp',
        }, {
            'name': 'Fashion',
            'image': '../assets/images/categories/fashion.webp',
        }, {
            'name': 'Grocery',
            'image': '../assets/images/categories/grocery.webp',
        }, {
            'name': 'Mobiles',
            'image': '../assets/images/categories/mobiles.webp',
        }, {
            'name': 'Appliances',
            'image': '../assets/images/categories/appliances.webp',
        }, {
            'name': 'HOme',
            'image': '../assets/images/categories/home.webp',
        }, {
            'name': 'Toys',
            'image': '../assets/images/categories/toys.webp',
        }
    ]
}
export default data