import React from 'react'
import AppBar from '../../AppBar/AppBar'

function Header() {
    return (
        <header>
            <AppBar />
        </header>
    )
}

export default Header